from distutils.core import setup

setup(
    name='backtest',
    version='1.0.0',
    py_modules=['backtest'],
    author='www',
    packages=['backtest/Constance','backtest/Dao','backtest/Entity','backtest/GUI','backtest/Main','backtest/Service','backtest/Test','backtest/Testcase','backtest/Util']
)