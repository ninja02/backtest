from backtestData.Dao import SourceDataDao
from backtest.Util import SelectUtil
from backtest.Util import DateUtil
from backtest.Util import SetUtil
from backtest.Entity import StockHoldEntity
from backtest.Entity import StockTradeEntityBak
from backtest.Util import NumUtil

from pandas import Series, DataFrame
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt

def main():


    print('0')
main()



